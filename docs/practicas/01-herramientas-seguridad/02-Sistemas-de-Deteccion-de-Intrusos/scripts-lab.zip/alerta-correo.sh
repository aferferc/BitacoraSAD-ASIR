#!/bin/bash
# alerta-correo.sh - Vigila las alertas de Snort y envia un correo cuando detecta una de prioridad alta

LOG_ALERTAS="/var/log/snort/alert_fast.txt"
DESTINO="gabrielbusiness2007@gmail.com"
CUENTA_MSMTP="gmail"
PATRON_PRIORIDAD="Priority: 1"
COOLDOWN=120
SENSOR="snort (10.20.30.40)"

ultimo_envio=0
contador=0

enviar_correo() {
    local alerta="$1"
    local total="$2"
    local asunto="[SNORT] Alerta de prioridad alta en la red SDI"
    local momento
    momento="$(date '+%Y-%m-%d %H:%M:%S')"
    {
        printf "Subject: %s\n" "$asunto"
        printf "\n"
        printf "El sensor Snort ha detectado actividad de prioridad alta.\n\n"
        printf "Ultima alerta:\n%s\n\n" "$alerta"
        printf "Alertas de prioridad alta desde el ultimo aviso: %s\n\n" "$total"
        printf "Sensor: %s\n" "$SENSOR"
        printf "Fecha: %s\n" "$momento"
    } | msmtp -a "$CUENTA_MSMTP" "$DESTINO"
}

procesar_linea() {
    local linea="$1"
    local ahora
    local es_prioritaria=0
    if printf "%s" "$linea" | grep -q "$PATRON_PRIORIDAD"; then
        es_prioritaria=1
    fi
    if [ "$es_prioritaria" -eq 1 ]; then
        contador=$((contador + 1))
        ahora="$(date +%s)"
        if [ $((ahora - ultimo_envio)) -ge "$COOLDOWN" ]; then
            enviar_correo "$linea" "$contador"
            ultimo_envio="$ahora"
            contador=0
        fi
    fi
}

main() {
    printf "Vigilando %s en busca de alertas con '%s'\n" "$LOG_ALERTAS" "$PATRON_PRIORIDAD"
    while IFS= read -r linea; do
        procesar_linea "$linea"
    done < <(tail -F -n 0 "$LOG_ALERTAS")
}

main
