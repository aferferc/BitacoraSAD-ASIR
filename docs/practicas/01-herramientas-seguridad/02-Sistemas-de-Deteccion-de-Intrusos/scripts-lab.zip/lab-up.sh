#!/bin/bash
# lab-up.sh - Arranca el laboratorio SDI: switch Open vSwitch, NAT del host, VMs y port mirroring de toda la red hacia el sensor Snort

BRIDGE="br-lab"
RED_LAB="10.20.30.0/24"
IP_HOST="10.20.30.1/24"
PUERTO_SENSOR="lab-snort-mon"
VMS="snort servidor cliente-linux cliente-windows atacante"

comprobar_root() {
    if [ "$(id -u)" -ne 0 ]; then
        printf "Ejecuta el script con sudo\n"
        exit 1
    fi
}

configurar_red_host() {
    if ! ovs-vsctl br-exists "$BRIDGE"; then
        ovs-vsctl add-br "$BRIDGE"
        printf "Bridge %s creado\n" "$BRIDGE"
    fi
    if ! ip addr show dev "$BRIDGE" | grep -q "${IP_HOST%/*}/"; then
        ip addr add "$IP_HOST" dev "$BRIDGE"
    fi
    ip link set "$BRIDGE" up
    sysctl -qw net.ipv4.ip_forward=1
    if ! nft list table ip lab >/dev/null 2>&1; then
        nft add table ip lab
        nft add chain ip lab post '{ type nat hook postrouting priority 100 ; }'
        nft add rule ip lab post ip saddr "$RED_LAB" oifname != "$BRIDGE" masquerade
    fi
    printf "Red del host lista: %s con salida NAT a internet\n" "$IP_HOST"
}

arrancar_vms() {
    for vm in $VMS; do
        if virsh list --name --state-running | grep -qx "$vm"; then
            printf "%s ya estaba encendida\n" "$vm"
        elif virsh dominfo "$vm" >/dev/null 2>&1; then
            virsh start "$vm" >/dev/null
            printf "%s arrancada\n" "$vm"
        else
            printf "%s no existe, se omite\n" "$vm"
        fi
    done
}

esperar_puerto() {
    local puerto="$1"
    local intentos=0
    while ! ovs-vsctl list-ports "$BRIDGE" | grep -qx "$puerto" && [ "$intentos" -lt 30 ]; do
        sleep 1
        intentos=$((intentos + 1))
    done
    ovs-vsctl list-ports "$BRIDGE" | grep -qx "$puerto"
}

configurar_mirror() {
    if ! virsh list --name --state-running | grep -qx "snort"; then
        printf "La VM snort no esta encendida: se omite el port mirroring\n"
    elif esperar_puerto "$PUERTO_SENSOR"; then
        ovs-vsctl clear Bridge "$BRIDGE" mirrors
        ovs-vsctl -- --id=@mon get Port "$PUERTO_SENSOR" \
                  -- --id=@m create Mirror name=span-sdi select-all=true output-port=@mon \
                  -- set Bridge "$BRIDGE" mirrors=@m >/dev/null
        printf "Port mirroring activo: toda la red %s -> %s\n" "$BRIDGE" "$PUERTO_SENSOR"
    else
        printf "No se encontro el puerto %s en %s\n" "$PUERTO_SENSOR" "$BRIDGE"
        exit 1
    fi
}

main() {
    comprobar_root
    configurar_red_host
    arrancar_vms
    configurar_mirror
    printf "Laboratorio listo\n"
}

main
