#!/bin/bash
# crear-vms.sh - Crea las VMs Debian del laboratorio SDI desde la imagen cloud de Debian 13, configuradas con cloud-init

DIR_IMAGENES="/var/lib/libvirt/images"
IMAGEN_BASE="$DIR_IMAGENES/debian-13-genericcloud-amd64.qcow2"
RED_LIBVIRT="lab-ovs"
BRIDGE="br-lab"
PASARELA="10.20.30.1"
PREFIJO="24"
DNS="1.1.1.1"
DOMINIO="lab-sdi.local"
USUARIO="${SUDO_USER:-gabriel}"
DIR_SCRIPT="$(cd "$(dirname "$0")" && pwd)"
DIR_CLOUDINIT="$DIR_SCRIPT/cloud-init"

MAQUINAS="snort:3072:2:25:10.20.30.40:lab-snort-mgmt:lab-snort-mon
servidor:1024:1:20:10.20.30.10:lab-servidor:
cliente-linux:768:1:15:10.20.30.21:lab-cli-linux:"

OS_VARIANT=""
HASH_CONTRASENA=""
CLAVE_SSH=""

comprobar_root() {
    if [ "$(id -u)" -ne 0 ]; then
        printf "Ejecuta el script con sudo\n"
        exit 1
    fi
}

comprobar_requisitos() {
    local correcto=1
    local comando
    for comando in virt-install virsh qemu-img openssl; do
        if ! command -v "$comando" >/dev/null 2>&1; then
            printf "Falta el comando %s\n" "$comando"
            correcto=0
        fi
    done
    if [ ! -f "$IMAGEN_BASE" ]; then
        printf "No se encuentra la imagen base %s\n" "$IMAGEN_BASE"
        correcto=0
    fi
    if ! virsh net-list --name 2>/dev/null | grep -qx "$RED_LIBVIRT"; then
        printf "La red %s de libvirt no esta activa (sudo virsh net-start %s)\n" "$RED_LIBVIRT" "$RED_LIBVIRT"
        correcto=0
    fi
    if ! ip -4 addr show dev "$BRIDGE" 2>/dev/null | grep -q "inet $PASARELA/"; then
        printf "El host no tiene la IP %s en %s: ejecuta antes sudo ./lab-up.sh\n" "$PASARELA" "$BRIDGE"
        correcto=0
    fi
    if [ "$correcto" -eq 0 ]; then
        exit 1
    fi
}

elegir_os_variant() {
    if osinfo-query os --fields=short-id 2>/dev/null | grep -qw "debian13"; then
        OS_VARIANT="debian13"
    else
        OS_VARIANT="debian12"
    fi
    printf "Variante de sistema para virt-install: %s\n" "$OS_VARIANT"
}

pedir_contrasena() {
    local primera=""
    local segunda=""
    local valida=0
    while [ "$valida" -eq 0 ]; do
        printf "Contrasena para el usuario %s en las VMs: " "$USUARIO"
        read -rs primera
        printf "\nRepitela: "
        read -rs segunda
        printf "\n"
        if [ -z "$primera" ]; then
            printf "La contrasena no puede estar vacia\n"
        elif [ "$primera" != "$segunda" ]; then
            printf "No coinciden, prueba otra vez\n"
        else
            valida=1
        fi
    done
    HASH_CONTRASENA="$(printf "%s" "$primera" | openssl passwd -6 -stdin)"
}

buscar_clave_ssh() {
    local dir_casa
    local fichero
    dir_casa="$(getent passwd "$USUARIO" | cut -d: -f6)"
    for fichero in id_ed25519.pub id_ecdsa.pub id_rsa.pub; do
        if [ -z "$CLAVE_SSH" ] && [ -f "$dir_casa/.ssh/$fichero" ]; then
            CLAVE_SSH="$(head -n 1 "$dir_casa/.ssh/$fichero")"
            printf "Se anadira tu clave SSH %s\n" "$fichero"
        fi
    done
    if [ -z "$CLAVE_SSH" ]; then
        printf "No hay clave SSH en %s/.ssh: se entrara solo con contrasena\n" "$dir_casa"
    fi
}

mac_gestion() {
    printf "52:54:00:20:30:%s" "${1##*.}"
}

mac_escucha() {
    printf "52:54:00:20:31:%s" "${1##*.}"
}

generar_user_data() {
    local nombre="$1"
    local es_sensor="$2"
    local fichero="$3"
    {
        printf '%s\n' \
            "#cloud-config" \
            "hostname: $nombre" \
            "fqdn: $nombre.$DOMINIO" \
            "manage_etc_hosts: true" \
            "timezone: Europe/Madrid" \
            "users:" \
            "  - name: $USUARIO" \
            "    groups: [sudo]" \
            "    shell: /bin/bash" \
            "    lock_passwd: false" \
            "    passwd: \"$HASH_CONTRASENA\""
        if [ -n "$CLAVE_SSH" ]; then
            printf '%s\n' \
                "    ssh_authorized_keys:" \
                "      - \"$CLAVE_SSH\""
        fi
        printf '%s\n' \
            "ssh_pwauth: true" \
            "package_update: true" \
            "package_upgrade: true" \
            "packages:" \
            "  - tcpdump"
        if [ "$es_sensor" -eq 1 ]; then
            printf '%s\n' \
                "  - ethtool" \
                "write_files:" \
                "  - path: /etc/systemd/system/escucha-snort.service" \
                "    permissions: '0644'" \
                "    content: |" \
                "      [Unit]" \
                "      Description=Interfaz de escucha de Snort (enp2s0) en modo promiscuo y sin IP" \
                "      After=network.target" \
                "" \
                "      [Service]" \
                "      Type=oneshot" \
                "      RemainAfterExit=yes" \
                "      ExecStart=/usr/sbin/sysctl -w net.ipv6.conf.enp2s0.disable_ipv6=1" \
                "      ExecStart=/usr/sbin/ip link set enp2s0 up promisc on" \
                "      ExecStart=-/usr/sbin/ethtool -K enp2s0 gro off lro off" \
                "" \
                "      [Install]" \
                "      WantedBy=multi-user.target" \
                "runcmd:" \
                "  - [systemctl, daemon-reload]" \
                "  - [systemctl, enable, --now, escucha-snort.service]" \
                "  - [touch, /etc/cloud/cloud-init.disabled]"
        else
            printf '%s\n' \
                "runcmd:" \
                "  - [touch, /etc/cloud/cloud-init.disabled]"
        fi
    } > "$fichero"
}

generar_network_config() {
    local ip="$1"
    local es_sensor="$2"
    local fichero="$3"
    {
        printf '%s\n' \
            "version: 2" \
            "ethernets:" \
            "  enp1s0:" \
            "    match:" \
            "      macaddress: \"$(mac_gestion "$ip")\"" \
            "    set-name: enp1s0" \
            "    dhcp4: false" \
            "    addresses:" \
            "      - $ip/$PREFIJO" \
            "    routes:" \
            "      - to: default" \
            "        via: $PASARELA" \
            "    nameservers:" \
            "      addresses:" \
            "        - $DNS"
        if [ "$es_sensor" -eq 1 ]; then
            printf '%s\n' \
                "  enp2s0:" \
                "    match:" \
                "      macaddress: \"$(mac_escucha "$ip")\"" \
                "    set-name: enp2s0" \
                "    dhcp4: false" \
                "    dhcp6: false" \
                "    optional: true"
        fi
    } > "$fichero"
}

crear_disco() {
    local disco="$1"
    local tamano="$2"
    qemu-img convert -O qcow2 "$IMAGEN_BASE" "$disco" </dev/null && qemu-img resize "$disco" "${tamano}G" </dev/null >/dev/null
}

crear_maquina() {
    local nombre="$1"
    local ram="$2"
    local cpus="$3"
    local tamano="$4"
    local ip="$5"
    local puerto_gestion="$6"
    local puerto_escucha="$7"
    local disco="$DIR_IMAGENES/$nombre.qcow2"
    local dir_vm="$DIR_CLOUDINIT/$nombre"
    local es_sensor=0
    local redes

    if [ -n "$puerto_escucha" ]; then
        es_sensor=1
    fi

    if virsh dominfo "$nombre" >/dev/null 2>&1; then
        printf "[%s] ya existe, se omite\n" "$nombre"
    elif [ -e "$disco" ]; then
        printf "[%s] ya existe el disco %s pero no la VM: revisalo y borralo a mano si sobra\n" "$nombre" "$disco"
    else
        printf "[%s] generando cloud-init en %s\n" "$nombre" "$dir_vm"
        mkdir -p "$dir_vm"
        generar_user_data "$nombre" "$es_sensor" "$dir_vm/user-data"
        generar_network_config "$ip" "$es_sensor" "$dir_vm/network-config"

        printf "[%s] creando disco de %s GB\n" "$nombre" "$tamano"
        if crear_disco "$disco" "$tamano"; then
            redes=(--network "network=$RED_LIBVIRT,model=virtio,target.dev=$puerto_gestion,mac=$(mac_gestion "$ip")")
            if [ "$es_sensor" -eq 1 ]; then
                redes+=(--network "network=$RED_LIBVIRT,model=virtio,target.dev=$puerto_escucha,mac=$(mac_escucha "$ip")")
            fi
            printf "[%s] creando VM (%s MB de RAM, %s vCPU, IP %s)\n" "$nombre" "$ram" "$cpus" "$ip"
            if virt-install \
                --name "$nombre" \
                --memory "$ram" --vcpus "$cpus" \
                --import \
                --disk "path=$disco,format=qcow2,bus=virtio" \
                --os-variant "$OS_VARIANT" \
                "${redes[@]}" \
                --cloud-init "user-data=$dir_vm/user-data,network-config=$dir_vm/network-config" \
                --graphics spice \
                --noautoconsole </dev/null >/dev/null; then
                printf "[%s] creada y arrancando\n" "$nombre"
            else
                printf "[%s] fallo virt-install; el disco %s se ha quedado creado\n" "$nombre" "$disco"
            fi
        else
            printf "[%s] no se pudo crear el disco\n" "$nombre"
        fi
    fi
}

main() {
    local nombre ram cpus tamano ip puerto_gestion puerto_escucha
    comprobar_root
    comprobar_requisitos
    elegir_os_variant
    pedir_contrasena
    buscar_clave_ssh
    mkdir -p "$DIR_CLOUDINIT"
    while IFS=: read -r nombre ram cpus tamano ip puerto_gestion puerto_escucha; do
        if [ -n "$nombre" ]; then
            crear_maquina "$nombre" "$ram" "$cpus" "$tamano" "$ip" "$puerto_gestion" "$puerto_escucha"
        fi
    done <<< "$MAQUINAS"
    chown -R "$USUARIO": "$DIR_CLOUDINIT"
    printf "\nListo. Cada VM tarda 1-3 minutos en aplicar cloud-init (actualiza paquetes).\n"
    printf "Despues ejecuta sudo ./lab-up.sh para activar el port mirroring hacia el sensor.\n"
    printf "Acceso: ssh %s@10.20.30.40 (snort), @10.20.30.10 (servidor), @10.20.30.21 (cliente-linux)\n" "$USUARIO"
}

main
