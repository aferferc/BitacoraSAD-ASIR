#!/bin/bash
# lab-down.sh - Apaga de forma ordenada las VMs del laboratorio SDI y, opcionalmente, crea un snapshot de cada una

VMS="atacante cliente-windows cliente-linux servidor snort"
ESPERA_MAXIMA=180
NOMBRE_SNAPSHOT=""
FORZAR=0

mostrar_ayuda() {
    printf "Uso: sudo ./lab-down.sh [-s nombre_snapshot] [-f]\n"
    printf "  -s nombre   crea un snapshot con ese nombre en cada VM tras apagarla\n"
    printf "  -f          fuerza el apagado de las VMs que no respondan en %s segundos\n" "$ESPERA_MAXIMA"
}

comprobar_root() {
    if [ "$(id -u)" -ne 0 ]; then
        printf "Ejecuta el script con sudo\n"
        exit 1
    fi
}

leer_opciones() {
    local opcion
    while getopts "s:fh" opcion; do
        case "$opcion" in
            s) NOMBRE_SNAPSHOT="$OPTARG" ;;
            f) FORZAR=1 ;;
            h) mostrar_ayuda; exit 0 ;;
            *) mostrar_ayuda; exit 1 ;;
        esac
    done
}

vm_existe() {
    virsh dominfo "$1" >/dev/null 2>&1
}

vm_encendida() {
    virsh list --name --state-running | grep -qx "$1"
}

pedir_apagado() {
    local vm
    for vm in $VMS; do
        if ! vm_existe "$vm"; then
            printf "%s no existe, se omite\n" "$vm"
        elif vm_encendida "$vm"; then
            virsh shutdown "$vm" >/dev/null
            printf "%s: apagado solicitado\n" "$vm"
        else
            printf "%s ya estaba apagada\n" "$vm"
        fi
    done
}

quedan_encendidas() {
    local vm
    local encendidas=""
    for vm in $VMS; do
        if vm_existe "$vm" && vm_encendida "$vm"; then
            encendidas="$encendidas $vm"
        fi
    done
    printf "%s" "$encendidas"
}

esperar_apagado() {
    local segundos=0
    local pendientes
    pendientes="$(quedan_encendidas)"
    while [ -n "$pendientes" ] && [ "$segundos" -lt "$ESPERA_MAXIMA" ]; do
        sleep 5
        segundos=$((segundos + 5))
        pendientes="$(quedan_encendidas)"
    done
    if [ -n "$pendientes" ]; then
        printf "Siguen encendidas tras %s segundos:%s\n" "$ESPERA_MAXIMA" "$pendientes"
        if [ "$FORZAR" -eq 1 ]; then
            forzar_apagado "$pendientes"
        else
            printf "Apagalas desde dentro o vuelve a lanzar el script con -f para forzarlas\n"
            exit 1
        fi
    else
        printf "Todas las VMs estan apagadas\n"
    fi
}

forzar_apagado() {
    local vm
    for vm in $1; do
        virsh destroy "$vm" >/dev/null
        printf "%s: apagado forzado\n" "$vm"
    done
}

crear_snapshots() {
    local vm
    for vm in $VMS; do
        if vm_existe "$vm"; then
            if virsh snapshot-info "$vm" "$NOMBRE_SNAPSHOT" >/dev/null 2>&1; then
                printf "%s: ya tiene un snapshot llamado %s, se omite\n" "$vm" "$NOMBRE_SNAPSHOT"
            elif virsh snapshot-create-as "$vm" "$NOMBRE_SNAPSHOT" >/dev/null 2>&1; then
                printf "%s: snapshot %s creado\n" "$vm" "$NOMBRE_SNAPSHOT"
            elif virsh snapshot-create-as "$vm" "$NOMBRE_SNAPSHOT" --disk-only --atomic >/dev/null 2>&1; then
                printf "%s: snapshot %s creado (solo disco, maquina UEFI)\n" "$vm" "$NOMBRE_SNAPSHOT"
            else
                printf "%s: no se pudo crear el snapshot\n" "$vm"
            fi
        fi
    done
}

main() {
    leer_opciones "$@"
    comprobar_root
    pedir_apagado
    esperar_apagado
    if [ -n "$NOMBRE_SNAPSHOT" ]; then
        crear_snapshots
    fi
    printf "Laboratorio apagado\n"
}

main "$@"
